<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" media="all" />
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>

 <style>
 .a{
 width: 100%;
 height: 100px;
 background-color:#afafa4;
 }
 
   .b{
 color:white;
  height: 300px;
  margin-bottom:30px;
 background-color:#a35151;
 }
 
  .c{
 width: 100%;
 height: 100px;
 margin-top:-30px;
 background-color:#5f5f5f;
 }

</style>	
</head>

<body>

<div class="container-fluid a">
<div class="row">
<div class="col-md-12">
<h1>CONTACT US</h1>
</div>
</div>
</div>

<div class="container-fluid b">
<div class="row">
<div class="col-md-12">
<form action="testaction.php" method="post" enctype="multipart/form-data">
<div class="form-group">
<label>Name</label>
<input type="text" name="nm">
</div>

<div class="form-group"><br>
<label>Mobile number</label>
<input type="number" name="mn">
</div>

<div class="form-group"><br>
<label>Email_Id</label>
<input type="text" name="em">
</div>

<div class="form-group"><br>
<label>Password</label>
<input type="password" name="pd">
</div>

<div class="form-group"><br>
<label>Choose Image</label><br>
<input type="file" name="pht">
</div>

<div class="form-group"><br>
<label>Select Gender</label><br>
Male<input type="radio" value="male" name="ml">
Female<input type="radio" value="female" name="ml"><br>
</div>

<br><button type="submit">Submit</button> 
</form>
</div>

</div>
</div>

<div class="container-fluid c">
<h1>Copyright @asus 2023 | privacy policy</h1>
</div>


</body>
</html>