<?php
require("connection.php");
$id=$_REQUEST["tx"];
$name = $_REQUEST["nm"];
$number = $_REQUEST["mn"];
$email = $_REQUEST["em"];
$password = $_REQUEST["pd"];
$gender = $_REQUEST["ml"];

if(empty($_FILES["pht"]))
{
$res=$con->query("UPDATE `test` SET `Name`='$name',`Mobile_Number`='$number',`Email_Id`='$email',`Password`='$password',`Gender`='$gender' where id='$id'");
$count=mysqli_affected_rows($con);
if($count>0)
{
header("location:view_test.php");
}
else{ 

}
}
else
{
 $pht=$_FILES["pht"]['name'];
 $res=$con->query("UPDATE `test` SET `Name`='$name',`Mobile_Number`='$number',`Email_Id`='$email',`Password`='$password',`Image`= '$pht',`Gender`='$gender' where id='$id'");
 $count=mysqli_affected_rows($con);
 move_uploaded_file($_FILES["pht"]['tmp_name'],"image/".$pht);
 header("location:view_test.php");
 }
 ?>