<?php

require("connection.php");
$name = $_REQUEST["nm"];
$number = $_REQUEST["mn"];
$email = $_REQUEST["em"];
$password = $_REQUEST["pd"];
$pht = $_FILES["pht"]["name"];
$gender = $_REQUEST["ml"];

$res=$con->query("insert into test(`Name`,`Mobile_Number`,`Email_Id`,`Password`,`Image`,`Gender`)values('$name','$number','$email','$password','$pht','$gender')");
$count=mysqli_affected_rows($con);

if($count>0)
{
move_uploaded_file($_FILES["pht"]['tmp_name'],"image/".$pht);
header("location:view_test.php");
}
else
{
header("location:test 1.php");
}

?>