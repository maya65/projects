<html>
<head>
<title>view_test</title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="css/table-style.css" />
<link rel="stylesheet" type="text/css" href="css/basictable.css" />
<link href="css/component.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style_grid.css" rel="stylesheet" type="text/css" media="all" />

<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->

 <link href="https://cdn.datatables.net/v/dt/dt-1.13.6/datatables.min.css" rel="stylesheet">
   
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>

<script type="text/javascript" src="js/jQuery-plugin-progressbar.min.js"></script>	

</head>

<body>
<table id="table">
<thead>

<tr>
<th>S.NO</th>
<th>Name</th>
<th>Mobile_Number</th>
<th>Email_Id</th>
<th>Password</th>
<th>Image</th>
<th>Gender</th>
<th>Edit</th>
<th>Delete</th>
</tr>
</thead>

<?php
require("connection.php");
$res=$con->query("select * from test");
$count=$res->num_rows;

if($count>0)
{
$no=1;
while($row=$res->fetch_assoc())
{
?>

<tbody>
<tr>
<td><?php echo $no++; ?> </td>
<td><?php echo $row["Name"];?></td>
<td><?php echo $row["Mobile_Number"];?></td>
<td><?php echo $row["Email_Id"];?></td>
<td><?php echo $row["Password"];?></td>
<td><img src="<?php echo "image/". $row["Image"];?>" style="width:150px; height:150px;"></td>
<td><?php echo $row["Gender"];?></td>
<td><a href="edittest.php?editid=<?php echo $row['id'];?>">Edit</a></td>
<td><a onclick="return confirm('Are you sure you want to delete this column?');" href="deletetest.php?deleteid=<?php echo $row['id'];?>">Delete</a></td>
</tr>
</tbody>

<?php
}
}
?>
</table>

<script src="https://cdn.datatables.net/v/dt/dt-1.13.6/datatables.min.js"></script>
   
                                    <script type="text/javascript">
                                        $(document).ready(function(){
										alert();	
	                                    $('#table').datatable();
                                        });
                                     </script>	
									 
</body>
</html>