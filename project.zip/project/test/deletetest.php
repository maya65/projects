<?php
require("connection.php");
$id=$_REQUEST["deleteid"];

$res=$con->query("select * from `test` where id='$id'");
$row=$res->fetch_assoc();
$photos='image/'.$row['Image'];
unlink($photos);

$res=$con-> query("DELETE from `test` WHERE id='$id'");
$count=mysqli_affected_rows($con);
if($count>0)
{
header("location:view_test.php");
}
else
{
header("location:test 1.php");
}
?>