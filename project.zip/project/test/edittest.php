<html>
<head>
<title></title>

<style>
.a{
 width: 100%;
 height: 100px;
 background-color:#afafa4;
 }
 
   .b{
 color:white;
  height: 450px;
  margin-bottom:30px;
 background-color:#a35151;
 }
 
  .c{
height:130px;	  
 margin-top:-30px;
 background-color:#5f5f5f;
 }

</style>

</head>
<body>

<?php
require("connection.php");
$id = $_REQUEST['editid'];

$res="select * from test where id='$id'";
$result=$con->query($res);

$count=$result->num_rows;
if($count>0)
{
$row=$result->fetch_assoc();
?>

 <div class="container-fluid a">
<div class="row">
<div class="col-md-12">
<h1>CONTACT US</h1>
</div>
</div>
</div>

<div class="container-fluid b">
<div class="row">
<div class="col-md-12">
<form action="edittest_action.php" method="post" enctype="multipart/form-data">

<input type="hidden" name="tx" value="<?php echo $row['id'];?>"> 

<div class="form-group">
<label>Name</label>
<input type="text" value="<?php echo $row['Name'];?>" name="nm">
</div>

<div class="form-group"><br>
<label>Mobile number</label>
<input type="number" value="<?php echo $row['Mobile_Number'];?>" name="mn">
</div>

<div class="form-group"><br>
<label>Email_Id</label>
<input type="text" value="<?php echo $row['Email_Id'];?>" name="em">
</div>

<div class="form-group"><br>
<label>Password</label>
<input type="password" value="<?php echo $row['Password'];?>" name="pd">
</div>

<div class="form-group"><br>
<label>Choose Image</label><br>
<input type="file" name="pht"><br> <img src="<?php echo "image/". $row["Image"];?>" style="width:150px; height:100px;">
</div>

<div class="form-group"><br>
<label>Select Gender</label>
Male<input type="radio" value="male" name="ml">
Female<input type="radio" value="female" name="ml"><br>
</div>

<br><button type="submit">Submit</button> 

</form>
</div>
</div>

</div>

<?php
}
?>
<div class="container-fluid c">
<div class="col-md-12">
<h1>Copyright @asus 2023 | privacy policy</h1>
</div>
 </div>
 
 </body>
 </html>