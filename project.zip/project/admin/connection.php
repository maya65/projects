<?php
$con=mysqli_connect("localhost","root","","admin"); //hostname,username,password,dbname
if(!$con)
{
  die("connection failed");
}  
 ?> 